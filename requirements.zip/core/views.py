from rest_framework.views import APIView
from rest_framework.response import Response
from .outils import merge_objects_from_json
from django.shortcuts import render, redirect
from django.db import models
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.parsers import MultiPartParser
from .models import ConsolidatedObjects, ObjectsFromCao, PropertyConsolidationParam
from .models import Ouvrage, FacteurChoc, DegreChoc, AvecPlot, AvecCarlingage, OwnerCodeDetails
from .serializers import DynamicConsolidatedObjectsSerializer,SerialObjectFromCao
from rest_framework.pagination import PageNumberPagination
from rest_framework.decorators import api_view
from .filter import ConsolidateFilter
from .serializers import SerialObjectFromCao as ObjectsFromCaoSerializer
from django.utils.dateparse import parse_datetime
from rest_framework import status
import json
import logging

from django.contrib.auth.views import LoginView
from .forms import CustomLoginForm
import pandas as pd
from django_tenants.utils import schema_context
from django.db.models.expressions import Window
from django.db.models.functions import DenseRank
from django.db.models import F, Q, Count
from django.core import serializers
from datetime import datetime
# from braces.views import CsrfExemptMixin
logger = logging.getLogger('core')
#for the login
class CustomLoginView(LoginView):
    authentication_form = CustomLoginForm

@login_required
def index(request):
    optionFacteurChoc = [element for element in FacteurChoc.objects.values('id', 'value').distinct().order_by('-id')]
    optionDegreChoc = [element for element in DegreChoc.objects.values('id', 'value').distinct().order_by('-id') ]
    optionavec_plots = [element for element in AvecPlot.objects.values('id', 'value').distinct().order_by('-id') ]
    optionaavec_carlingage = [element for element in AvecCarlingage.objects.values('id', 'value').distinct().order_by('-id') ]
    ouv= request.session['SelectedOuvrage'].lower()   
    with schema_context(ouv):  
        # queryset = ConsolidateFilter(request.GET, queryset=ConsolidatedObjects.objects.all())
        queryset=ConsolidatedObjects.objects.all()
        dataOption = {
            "facteur_choc" : optionFacteurChoc,
            "degre_choc" : optionDegreChoc,
            "avec_plots" : optionavec_plots,
            "avec_carlingage" : optionaavec_carlingage
        }
        context = {        
            "tables_consolide": queryset,
            "checkSelection":dataOption
        }
        return render(request, 'pages/home.html', context)
    
def home2(request):
    return render(request, 'pages/table.html')

@login_required
def menu(request):   
    ouvrageSelected = request.GET.get('ouvrage')
    request.session['SelectedOuvrage'] = ouvrageSelected    
    list_ouvrage = Ouvrage.objects.all().filter(is_active=True).values_list('ouvrage','type','description','image').distinct().order_by('-ouvrage')
    context = {
        "datas": "consolidated_data",
        "formulaire": "si besoin",
        "listofOuvrage": list_ouvrage,
    }
    return render(request, 'pages/menu.html', context)

class ImportJsonView(APIView):
    authentication_classes = []
    parser_classes = [MultiPartParser] 
    def post(self, request):
        if 'file' not in request.FILES:
            return Response({"error": "No file uploaded"}, status=status.HTTP_400_BAD_REQUEST)        
        file = request.FILES['file']
        try:
            import json
            data = json.load(file)            
            Project = data['Project'].lower()
            Source = data['Source']
            dt_processing = datetime.strptime(data['DateTraitement'], "%Y%m%d%H%M%S")
            # load datas sjon           
            with schema_context(Project):
                df_raw = pd.DataFrame(data["Datas"])
                df_raw["source"] =  Source 
                df_raw["project"] = Project
                df_raw["dt_processing"] = dt_processing
                df_raw.rename(columns={
                    "Oid": "uid",
                    "Name": "name",
                    "ComponentType": "component_type",
                    "Description": "description",
                    "Trade": "trade",
                    "Function": "function",
                    "Lot": "lot",
                    "Room": "room",
                    "CodeFournisseur": "code_fournisseur",
                    "FacteurChoc": "facteur_choc_id",
                    "DegreChoc":"degre_choc_id",
                    "AvecPlots":"avec_plots_id",
                    "AvecCarlingage": "avec_carlingage_id"
                }, inplace=True)
                # check df_raw if ok and load then load it into database
                # merge_objects_from_json
                df_raw = df_raw.where(pd.notnull(df_raw), None) 
                list_of_dicts = df_raw.to_dict(orient='records') 
                retour = merge_objects_from_json(list_of_dicts)
                return Response({"message": "Data imported and flagged successfully", "data": retour}, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            print(e)
            return Response({"error": "Invalid JSON file", "error_details": str(e)}, status=status.HTTP_400_BAD_REQUEST) 


class GetObjectConsolidated(APIView):
    def get(self, request):
        ouvrage = request.GET.get('ouvrage')
        if ouvrage:
            ouvrage = ouvrage.lower()
            with schema_context(ouvrage):
                try: 
                    ObjectGrouper = ObjectsFromCao.objects.annotate(
                        rank=Window(
                            expression=DenseRank(),
                            order_by=F('name').asc()
                        )
                    ).exclude(status='D').order_by('rank').values()
                    ConsolidationRules = PropertyConsolidationParam.objects.values("property_name", "source_priority", "display_mode")                  
                    json_data = list(ObjectGrouper)
                    rules = list(ConsolidationRules)
                    lisofcol = [k['property_name'] for k in rules]                   
                    df_data = pd.DataFrame(json_data)                   
                    unique_values = df_data['rank'].unique()                                      
                    consolidate_row = []
                    for g in unique_values:
                        row_consolide = {}
                        df_ = df_data[df_data['rank'] == g]
                        if len(df_) == 1:  
                            consolidate_row.append(df_.iloc[0][lisofcol].to_dict())                                 
                        else:
                            for rule in rules:
                                col_name = rule['property_name']
                                flag = rule['display_mode'].lower()
                                priorites  = rule['source_priority']
                                if len(priorites) == 0:
                                    priorites = []
                                else:
                                    priorites = priorites.split(";")
                                resultat = []     
                                if len(priorites) > 0:
                                    for priorite in priorites:                   
                                        filtre = df_['source'] == priorite
                                        if filtre.any():
                                            if flag == 'first':                           
                                                ligne_min_id = df_.loc[filtre].nsmallest(1, 'id')
                                                resultat = ligne_min_id[col_name].iloc[0]
                                                if resultat is not None:
                                                    resultat = [str(resultat)]  
                                            elif flag == 'all':                            
                                                resultat.extend(df_.loc[filtre, col_name].tolist())
                                else: 
                                
                                    if flag == 'first':                    
                                        ligne_min_id = df_.nsmallest(1, 'id')
                                        resultat = [ligne_min_id[col_name].iloc[0]]
                                    elif flag == 'all':                                                                            
                                        resultat = df_[col_name].tolist()
                                if 'id' in col_name:
                                        print("************", col_name, resultat)
                                if resultat is not None:                
                                    resultat = list(set(resultat)) 
                                    resultat.sort() 
                                    resultat_concatene = ";".join(resultat) 
                                    if resultat_concatene.startswith(";"):
                                        resultat_concatene = resultat_concatene.replace(";","")                                   
                                    row_consolide[col_name] = resultat_concatene
                                else:                                    
                                    row_consolide[col_name] = ""
                            consolidate_row.append(row_consolide)
                    #load consolidation
                    ConsolidatedObjects.objects.bulk_create([ConsolidatedObjects(**t) for t in consolidate_row])
                    #                   
                    return Response({'datas': consolidate_row, 'ouvrage': ouvrage}, status=status.HTTP_200_OK)
                except Exception as e:
                    return Response ({'error':str(e)}, status=status.HTTP_406_NOT_ACCEPTABLE)
        else:
            return Response({"error": "aucune ouvrage a été séléctionner"}, status=status.HTTP_400_BAD_REQUEST)

class CheckOwnerCodeUnicity(APIView):
    def get(self, request):
        if not request.GET.get('ouvrage') and not request.GET.get('code_client'):
            return Response({"error": "il faut spécifier un ouvrage et le code_client à vérifier"}, status=status.HTTP_400_BAD_REQUEST)
        ouvrage = request.GET.get('ouvrage').lower()
        code_client = request.GET.get('code_client')
        with schema_context(ouvrage):
            retour = ConsolidatedObjects.objects.filter(code_client_object__iexact=code_client).count()           
            if retour == 0:
                return Response({'status': True}, status=status.HTTP_200_OK) # unique
            return  Response({'status': False}, status=status.HTTP_200_OK) # not unique
        
class CheckNameUnicity(APIView):
    def get(self, request):
        if not request.GET.get('ouvrage') and not request.GET.get('name'):
            return Response({"error": "il faut spécifier un ouvrage et un repère fonctionnel"}, status=status.HTTP_400_BAD_REQUEST)
        ouvrage = request.GET.get('ouvrage').lower()
        name = request.GET.get('name')
        with schema_context(ouvrage):
            retour = ConsolidatedObjects.objects.filter(name__iexact=name).count()           
            if retour == 0:
                return Response({'status': True}, status=status.HTTP_200_OK) # unique
            return  Response({'status': False}, status=status.HTTP_200_OK) # not unique
        
class GetdataCondolided(APIView):
    def get(self, request):
        ouvrage  = request.GET.get('ouvrage')
        if ouvrage:
            with schema_context(ouvrage.lower()):
                retour = ConsolidatedObjects.objects.values()
                return Response({"ouvrage": ouvrage, "datas": retour}, status=status.HTTP_200_OK)                
        else:
            return Response({"error": "selectionne un ouvrage"}, status=status.HTTP_400_BAD_REQUEST)

class CustomPagination(PageNumberPagination):
    # Le paramètre de taille de page utilisé par DataTables
    page_size_query_param = 'length'
    # Le paramètre de pagination "start" utilisé par DataTables
    page_query_param = 'start'
    
    # On définit une taille de page par défaut (optionnel)
    page_size = 10
    
    def get_page_number(self, request, paginator):
        """
        Cette méthode est nécessaire pour convertir le paramètre 'start' (utilisé par DataTables)
        en numéro de page correct pour la pagination.
        """
        page_size = self.get_page_size(request)
        start = int(request.GET.get(self.page_query_param, 0))  # Valeur de 'start' par défaut à 0
        page_number = start // page_size + 1  # Calcul du numéro de page
        return page_number

@api_view(['GET'])
def consolidated_objects(request):
    draw = int(request.GET.get('draw', 1))  # Identifiant unique DataTables
    start = int(request.GET.get('start', 0))  # Index de départ
    length = int(request.GET.get('length', 10))  # Nombre de lignes par page
    
    column_index = int(request.GET.get('order[0][column]', 0))  # Index de la colonne sur laquelle trier
    column_name = request.GET.get(f'columns[{column_index}][data]', 'id')  # Nom de la colonne
    order_dir = request.GET.get('order[0][dir]', 'asc') 
    
    ouvrage = request.GET.get('ouvrage')
    
    # Vérifier si "ouvrage" est vide ou None
    if not ouvrage:
        return Response({"error": "Ouvrage is required"}, status=400)

    with schema_context(ouvrage.lower()):
        queryset = ConsolidatedObjects.objects.all()        
        # Stocker le total une seule fois
        total_records = queryset.count()
        if order_dir == 'asc':
            queryset = queryset.order_by(column_name)
        else:
            queryset = queryset.order_by(f'-{column_name}')

        # Appliquer la pagination
        paginator = CustomPagination()
        paginator.page_size = length
        paginated_queryset = paginator.paginate_queryset(queryset, request)        
        # Vérifier si la pagination a bien retourné des résultats
        if paginated_queryset is None:
            paginated_queryset = []
        serializer = DynamicConsolidatedObjectsSerializer(
            paginated_queryset,
            many=True,
            fields=[
                "id",
                "name",
                "source",
                "description",
                "component_type",
                "trade",
                "function",
                "lot",
                "room",
                "code_client_object",
                "code_fournisseur",
                "facteur_choc",  # Correction : Suppression de l'espace en trop
                "degre_choc",
                "avec_plots",
                "avec_carlingage",
                "creation_date",
                "date_last_modified",
                "generate_data_config"
            ]
        )
        return Response({
            "draw": draw,
            "recordsTotal": total_records,
            "recordsFiltered": total_records,
            "data": serializer.data
        })



@api_view(['GET'])
def filtered_objects(request):
    """
    API pour filtrer les objets en fonction de l'ouvrage et d'une date donnée.
    Prend en charge la pagination via les paramètres `page` (offset) et `limit`.
    """
    ouvrage = request.GET.get('ouvrage', None)
    date_str = request.GET.get('date', None)
    limit = request.GET.get('limit', 10)
    if not ouvrage:
        return Response({"error": "Ouvrage is required"}, status=400)
    
    with schema_context(ouvrage.lower()):
        queryset = ObjectsFromCao.objects.all()

        if ouvrage:
            queryset = queryset.filter(name__icontains=ouvrage)

        if date_str:
            try:
                date_filter = parse_datetime(date_str)
                if date_filter:
                    queryset = queryset.filter(date_last_modified_dc__gte=date_filter)
            except ValueError:
                return Response({"error": "Format de date invalide. Utilisez YYYY-MM-DDTHH:MM:SSZ"}, status=400)

        # Pagination personnalisée
        paginator = PageNumberPagination()
        paginator.page_size = int(limit)
        paginated_queryset = paginator.paginate_queryset(queryset, request)

        serializer = ObjectsFromCaoSerializer(paginated_queryset, many=True)
        return paginator.get_paginated_response(serializer.data)
    
@api_view(['PUT'])
def update_objects(request):
    """
    API pour mettre à jour un ou plusieurs champs des objets ayant le même `name`.
    Requête JSON attendue : { "name": "nom_objet", "fields": { "champ1": "valeur1", "champ2": "valeur2" } }
    """
    data = request.data
    name = data.get("name")
    ouvrage = data.get("ouvrage")
    fields_to_update = data.get("fields", {})

    if not name or not fields_to_update or ouvrage:
        return Response({"error": "Le paramètre 'name', 'fields' et ouvrage sont requis"}, status=status.HTTP_400_BAD_REQUEST)
    
    with schema_context(ouvrage.lower()):        
        # Récupérer les objets correspondants
        objects = ObjectsFromCao.objects.filter(name=name)

        if not objects.exists():
            return Response({"error": f"Aucun objet trouvé avec le name '{name}'"}, status=status.HTTP_404_NOT_FOUND)

        # Mise à jour en une seule requête SQL
        updated_count = objects.update(**fields_to_update)

        return Response({
            "message": f"{updated_count} enregistrement(s) mis à jour.",
            "updated_fields": fields_to_update
        }, status=status.HTTP_200_OK)
                
@api_view(['POST'])
def check_code_client_exists(request):
    """
    Vérifie si un code_client_object existe déjà en fonction des valeurs des inputs.
    """
    input_values = request.data.get('inputs', {})  # Dictionnaire de valeurs {fieldorder: fieldvalue}

    if not input_values:
        return Response({"error": "Aucune donnée fournie"}, status=status.HTTP_400_BAD_REQUEST)

    # Trier les entrées en fonction de fieldorder pour respecter l'ordre
    sorted_inputs = sorted(input_values.items(), key=lambda x: int(x[0]))

    # Reconstruire la clé unique du code client (concaténation des valeurs triées)
    generated_code = "-".join(value for _, value in sorted_inputs)

    # Vérifier si un code similaire existe déjà en base
    existing_codes = (
        OwnerCodeDetails.objects.values('objconso')  # Récupérer les objets consolidés existants
        .annotate(code_client_object=models.functions.Concat('fieldvalue', models.Value('-')))
        .values_list('code_client_object', flat=True)  # Liste des codes existants
    )

    # Vérifier si notre code généré est dans les existants
    code_exists = generated_code in existing_codes

    return Response({"exists": code_exists}, status=status.HTTP_200_OK)            

                

        