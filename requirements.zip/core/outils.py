import pandas as pd
from .models import ObjectsFromCao, PropertyConsolidationParam, Ouvrage
from .models import FacteurChoc, DegreChoc, AvecCarlingage, AvecPlot
from datetime import date
from django.utils.timezone import now
# from django_tenants.utils import schema_context


def getListCategorie():
    listcat = Ouvrage.objects.values("ouvrage","id").distinct()
    return [(c['ouvrage'], c['id']) for c in listcat]




def merge_objects_from_json(source_data):
    """
    Fonction qui effectue le traitement de fusion :
    - Met à jour les objets existants
    - Insère les nouveaux objets
    - Flague les objets absents
    """

    # Récupérer les UIDs de la source
    source_uids = {item['uid'] for item in source_data}
    TargetData = ObjectsFromCao.objects.all()
    targetList = {f.uid for f in TargetData}
    ToUpdateInTarget = source_uids.intersection(targetList)
    ToInsertInTarget = source_uids - targetList
    ToFlaged = targetList - source_uids
    #insertion
    new_objects = [
        ObjectsFromCao(
            uid=item['uid'],
            source=item['source'],
            name=item['name'],
            component_type=item.get('component_type'),
            description=item.get('description'),
            trade=item.get('trade'),
            function=item.get('function'),
            lot=item.get('lot'),
            room=item.get('room'),   
            code_fournisseur=item.get('code_fournisseur'),
            facteur_choc = FacteurChoc.objects.get(value=item.get('facteur_choc_id')),
            degre_choc = DegreChoc.objects.get(value=item.get('degre_choc_id')),
            avec_plots = AvecPlot.objects.get(value=item.get('avec_plots_id')),
            avec_carlingage = AvecCarlingage.objects.get(value=item.get('avec_carlingage_id')),
            date_traitement_cao = item.get('dt_processing'),
            creation_date=now(),
            date_last_modified_dc = now(),
            status='A'
        )
        for item in source_data
        if item['uid'] in ToInsertInTarget
    ]
    ObjectsFromCao.objects.bulk_create(new_objects, ignore_conflicts=True)

    #update
    existing_objects = TargetData.filter(uid__in =ToUpdateInTarget)
    for obj in existing_objects:
        data = next(item for item in source_data if item['uid'] == obj.uid)
        # obj.source = data['source']
        # obj.name = data['name']
        # obj.component_type = data.get('component_type')
        # obj.description = data.get('description')
        # obj.trade = data.get('trade')
        # obj.function = data.get('function')
        # obj.lot = data.get('lot')
        # obj.room = data.get('room')    
        obj.code_fournisseur = data.get('code_fournisseur')
        obj.facteur_choc = FacteurChoc.objects.get(value=data.get('facteur_choc_id'))
        obj.degre_choc = DegreChoc.objects.get(value=data.get('degre_choc_id'))
        obj.avec_plots = AvecPlot.objects.get(value=data.get('avec_plots_id'))
        obj.avec_carlingage = AvecCarlingage.objects.get(value=data.get('avec_carlingage_id'))
        obj.date_traitement_cao = data.get('dt_processing')
        obj.date_last_modified_dc = now()
        obj.status='M'
        obj.save()   
     
    # Flager les objets absents dans la source
    ObjectsFromCao.objects.filter(
        uid__in=ToFlaged
    ).update(date_last_modified=date.today(), status='D')
    return {"ToFlaged": ToFlaged}